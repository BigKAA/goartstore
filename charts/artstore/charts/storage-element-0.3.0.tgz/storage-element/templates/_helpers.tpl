{{/*
Полное имя ресурса: storage-element-{elementId}
*/}}
{{- define "se.fullname" -}}
storage-element-{{ .Values.elementId }}
{{- end }}

{{/*
Имя chart для label helm.sh/chart
*/}}
{{- define "se.chart" -}}
{{ .Chart.Name }}-{{ .Chart.Version | replace "+" "_" }}
{{- end }}

{{/*
Полный путь к образу контейнера
*/}}
{{- define "se.image" -}}
{{ .Values.registry }}/{{ .Values.image }}:{{ .Values.tag }}
{{- end }}

{{/*
Стандартные Kubernetes labels
*/}}
{{- define "se.labels" -}}
helm.sh/chart: {{ include "se.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: artstore
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{ include "se.selectorLabels" . }}
{{- end }}

{{/*
Selector labels для Service → Pod matching
*/}}
{{- define "se.selectorLabels" -}}
app.kubernetes.io/name: storage-element
app.kubernetes.io/instance: {{ .Values.elementId }}
{{- end }}

{{/*
Имя TLS Secret (cert-manager или existingSecret)
*/}}
{{- define "se.tlsSecretName" -}}
{{- if .Values.tls.existingSecret -}}
{{ .Values.tls.existingSecret }}
{{- else -}}
{{ include "se.fullname" . }}-tls
{{- end -}}
{{- end }}

{{/*
Имя PVC для data
*/}}
{{- define "se.dataPvcName" -}}
{{ include "se.fullname" . }}-data
{{- end }}

{{/*
Общие env-переменные SE
*/}}
{{- define "se.envVars" -}}
- name: SE_PORT
  value: {{ .Values.port | quote }}
- name: SE_STORAGE_ID
  value: {{ .Values.elementId | quote }}
- name: DEPHEALTH_NAME
  value: {{ include "se.fullname" . | quote }}
- name: SE_DATA_DIR
  value: "/data"
- name: SE_MODE
  value: {{ .Values.mode | quote }}
- name: SE_MAX_FILE_SIZE
  value: {{ .Values.maxFileSize | quote }}
- name: SE_MAX_CAPACITY
  value: {{ .Values.maxCapacity | quote }}
- name: SE_GC_INTERVAL
  value: {{ .Values.gcInterval | quote }}
- name: SE_RECONCILE_INTERVAL
  value: {{ .Values.reconcileInterval | quote }}
- name: SE_UPLOAD_LOCK_TTL
  value: {{ .Values.uploadLockTTL | quote }}
- name: SE_MODE_SYNC_INTERVAL
  value: {{ .Values.modeSyncInterval | quote }}
- name: SE_INDEX_SYNC_INTERVAL
  value: {{ .Values.indexSyncInterval | quote }}
- name: SE_JWKS_URL
  value: {{ .Values.jwksUrl | quote }}
{{- if .Values.caCertPath }}
- name: SE_CA_CERT_PATH
  value: {{ .Values.caCertPath | quote }}
{{- end }}
{{- if .Values.tlsSkipVerify }}
- name: SE_TLS_SKIP_VERIFY
  value: {{ .Values.tlsSkipVerify | quote }}
{{- end }}
- name: SE_TLS_CERT
  value: "/certs/tls.crt"
- name: SE_TLS_KEY
  value: "/certs/tls.key"
- name: SE_LOG_LEVEL
  value: {{ .Values.logLevel | quote }}
- name: SE_LOG_FORMAT
  value: {{ .Values.logFormat | quote }}
- name: SE_DEPHEALTH_CHECK_INTERVAL
  value: {{ .Values.dephealthCheckInterval | quote }}
- name: SE_DEPHEALTH_GROUP
  value: {{ .Values.dephealthGroup | quote }}
- name: SE_DEPHEALTH_DEP_NAME
  value: {{ .Values.dephealthDepName | quote }}
{{- if .Values.dephealthIsEntry }}
- name: DEPHEALTH_ISENTRY
  value: "true"
{{- end }}
- name: SE_SHUTDOWN_TIMEOUT
  value: {{ .Values.shutdownTimeout | quote }}
{{- with .Values.timeouts }}
{{- if .httpClient }}
- name: SE_HTTP_CLIENT_TIMEOUT
  value: {{ .httpClient | quote }}
{{- end }}
{{- if .jwksClient }}
- name: SE_JWKS_CLIENT_TIMEOUT
  value: {{ .jwksClient | quote }}
{{- end }}
{{- if .httpRead }}
- name: SE_HTTP_READ_TIMEOUT
  value: {{ .httpRead | quote }}
{{- end }}
{{- if .httpWrite }}
- name: SE_HTTP_WRITE_TIMEOUT
  value: {{ .httpWrite | quote }}
{{- end }}
{{- if .httpIdle }}
- name: SE_HTTP_IDLE_TIMEOUT
  value: {{ .httpIdle | quote }}
{{- end }}
{{- if .jwksRefreshInterval }}
- name: SE_JWKS_REFRESH_INTERVAL
  value: {{ .jwksRefreshInterval | quote }}
{{- end }}
{{- if .jwtLeeway }}
- name: SE_JWT_LEEWAY
  value: {{ .jwtLeeway | quote }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Volume mounts для data и TLS сертификатов
*/}}
{{- define "se.volumeMounts" -}}
- name: data
  mountPath: /data
- name: tls-certs
  mountPath: /certs
  readOnly: true
{{- end }}

{{/*
Liveness и readiness probes (HTTPS)
*/}}
{{- define "se.probes" -}}
livenessProbe:
  httpGet:
    path: /health/live
    port: https
    scheme: HTTPS
  initialDelaySeconds: 15
  periodSeconds: 30
  timeoutSeconds: 5
  failureThreshold: 3
readinessProbe:
  httpGet:
    path: /health/ready
    port: https
    scheme: HTTPS
  initialDelaySeconds: 10
  periodSeconds: 15
  timeoutSeconds: 5
  failureThreshold: 3
{{- end }}
